<%-- SessionTracking.jsp : Identifies returning users using HttpSession --%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.Date" %>
<!DOCTYPE html>
<html>
<head><title>Session Tracking Demo</title></head>
<body>
<h2>Session Tracking - Identifying Returning Users</h2>

<%
    // isNew() tells us whether this session was just created (first visit)
    // or already existed (returning user within the same session)

    if (session.isNew()) {
        // First-time visitor: store visit count and first-access time
        session.setAttribute("visitCount", 1);
        session.setAttribute("firstVisit", new Date());
        out.println("<p>Welcome! This is your <b>first visit</b>.</p>");
    } else {
        // Returning visitor: increment the visit counter stored in session
        Integer count = (Integer) session.getAttribute("visitCount");
        if (count == null) {
            count = 1;
        }
        count = count + 1;
        session.setAttribute("visitCount", count);

        out.println("<p>Welcome back! You have visited this page <b>" 
                     + count + "</b> time(s) in this session.</p>");
        out.println("<p>Your session started at: " 
                     + session.getAttribute("firstVisit") + "</p>");
    }
%>

<hr>
<p><b>Session ID:</b> <%= session.getId() %></p>
<p><b>Session Creation Time:</b> <%= new Date(session.getCreationTime()) %></p>
<p><b>Last Accessed Time:</b> <%= new Date(session.getLastAccessedTime()) %></p>
<p><b>Max Inactive Interval:</b> <%= session.getMaxInactiveInterval() %> seconds</p>

<hr>
<p>Reload this page (or click below) to see the visit counter increase --
this confirms the server recognizes you as a returning user via the
JSESSIONID cookie maintained automatically by the servlet container.</p>
<a href="4_SessionTracking.jsp">Reload Page</a> |
<a href="4_Logout.jsp">Logout / End Session</a>

</body>
</html>
