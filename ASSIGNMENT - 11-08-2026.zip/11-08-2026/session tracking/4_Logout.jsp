<%-- Logout.jsp : Invalidates the current session --%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    session.invalidate();  // Destroys the session and all its attributes
%>
<!DOCTYPE html>
<html>
<head><title>Logged Out</title></head>
<body>
    <h2>Session Ended</h2>
    <p>Your session has been invalidated. If you visit the tracking page again,
       you will be treated as a new (first-time) visitor.</p>
    <a href="4_SessionTracking.jsp">Go to Session Tracking Page</a>
</body>
</html>
