<%-- register.jsp : Processes data submitted from 1_registration.html --%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.Date" %>
<!DOCTYPE html>
<html>
<head>
    <title>Registration Successful</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f2f2f2; }
        .result-box {
            width: 400px; margin: 50px auto; background: #fff;
            padding: 25px; border-radius: 8px; box-shadow: 0 0 10px #ccc;
        }
        h2 { color: #4CAF50; }
        p { font-size: 15px; }
    </style>
</head>
<body>
<div class="result-box">
<%
    // Reading form parameters sent from the HTML form
    String name = request.getParameter("name");
    String email = request.getParameter("email");
    String course = request.getParameter("course");

    // Simple server-side validation (real-time logic embedded in JSP)
    if (name == null || name.trim().equals("")) {
%>
        <h2 style="color:red;">Error: Name field cannot be empty!</h2>
        <a href="1_registration.html">Go Back</a>
<%
    } else {
%>
        <h2>Registration Successful!</h2>
        <p><b>Name:</b> <%= name %></p>
        <p><b>Email:</b> <%= email %></p>
        <p><b>Course:</b> <%= course %></p>
        <p><b>Registered On:</b> <%= new Date() %></p>
<%
    }
%>
</div>
</body>
</html>
