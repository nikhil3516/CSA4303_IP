<%-- CookieDemo.jsp : Demonstrates creating and sending a cookie to the browser --%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    // Step 1: Create a cookie with name "username" and value "John"
    Cookie cookie = new Cookie("username", "John");

    // Step 2: Set cookie properties (optional but recommended)
    cookie.setMaxAge(60 * 60 * 24);   // Cookie valid for 1 day (in seconds)
    cookie.setPath("/");              // Cookie available across the whole application

    // Step 3: Add/send the cookie to the client's browser
    response.addCookie(cookie);
%>
<!DOCTYPE html>
<html>
<head><title>Cookie Program</title></head>
<body>
    <h2>Cookie Created Successfully!</h2>
    <p>A cookie named <b>"username"</b> with value <b>"John"</b> has been sent to your browser.</p>
    <p>Visit <a href="3_ReadCookie.jsp">ReadCookie.jsp</a> to read it back.</p>
</body>
</html>
