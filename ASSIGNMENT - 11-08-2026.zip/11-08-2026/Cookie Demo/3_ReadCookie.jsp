<%-- ReadCookie.jsp : Reads all cookies sent by the browser --%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head><title>Read Cookie</title></head>
<body>
<h2>Cookies Received from Browser</h2>
<%
    // Get all cookies sent by the client
    Cookie[] cookies = request.getCookies();

    if (cookies != null) {
        for (Cookie c : cookies) {
            if (c.getName().equals("username")) {
%>
                <p>Cookie Name: <b><%= c.getName() %></b></p>
                <p>Cookie Value: <b><%= c.getValue() %></b></p>
                <p>Welcome back, <%= c.getValue() %>!</p>
<%
            }
        }
    } else {
%>
        <p>No cookies found. Please visit CookieDemo.jsp first.</p>
<%
    }
%>
</body>
</html>
